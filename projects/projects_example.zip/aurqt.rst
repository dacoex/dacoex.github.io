.. title: aurqt
.. slug: aurqt
.. date: 1970-01-01T00:00:00+00:00
.. description: A graphical AUR manager.
.. status: 7
.. logo: /projects/_logos/aurqt.png
.. github: https://github.com/Kwpolska/aurqt
.. bugtracker: https://github.com/Kwpolska/aurqt/issues
.. role: Maintainer
.. license: 3-clause BSD
.. featured: False
.. language: Python
.. sort: 10

aurqt, the graphical AUR manager, has been abandoned and is not available
anymore due to multiple changes in the AUR itself and the status of the code
base that would require a full rewrite.  I apologize for the inconvenience.

aurqt depended on `PKGBUILDer <../pkgbuilder/>`_ for most features.

(If anyone wants to take over development, please contact me.)
