.. title: Android Flashlight
.. slug: android_flashlight
.. date: 1970-01-01T00:00:00+00:00
.. description: Yet another Android flashlight.
.. status: 7
.. download: https://github.com/Kwpolska/flashlight/releases
.. github: https://github.com/Kwpolska/flashlight
.. role: Maintainer
.. license: 3-clause BSD
.. language: Java
.. sort: 1

This is yet another Android flashlight.  It does the usual thing: turn the
camera flash LED on.  It can’t do anything else.

This is a code dump/proof-of-concept.
